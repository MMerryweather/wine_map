Surface Geology of Australia, 1:2 500 000 scale, 2012 edition

DATA FORMAT: shapefile

DATASET DESCRIPTION:  Please read the dataset documentation in the metadata folder.

Please note that the shapefiles and associated layer (legend) files have been created 
using ArcGIS v10 software. Every effort has been made to ensure that all files are also
compatible with ArcGIS v9 software, but ArcGIC users are recommended to use ArcGIS v10 
to view the shapefiles if possible.

-------------------------------------------
14 December 2012